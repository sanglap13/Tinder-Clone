import React from 'react';
import './App.css';
import Footer from './Footer';
import Header from './Header';
import TinderCards from './TinderCards';

function App() {
  return (
    //BEM class naming convention
    <div className="app">
      

      <Header />

     
      <TinderCards />
      {/*swipebuttons*/}
      
      <Footer />

      {/*chatscreen*/}
      {/*individual chatscreen*/}

      
    </div>
  );
}

export default App;
