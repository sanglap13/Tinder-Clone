import React, { useEffect, useState } from 'react';
//import React, { useState } from 'react';
import TinderCard from 'react-tinder-card';
import './TinderCards.css'
import axios from './axios';

function TinderCards() {

     const [cars, setCars] = useState([
       /*{
            name: 'Ankkita',
            location: 'Mumbai',
            url:'https://celebfleet.com/wp-content/uploads/2022/08/Ankkita-C.webp'
        },
        {
            name: 'Tbone',
            location: 'Bangalore',
            url: 'https://celebfleet.com/wp-content/uploads/2022/08/tbone-bio-819x1024.webp'
        },
        {
            name: 'Kaashvi',
            location: 'Delhi',
            url: 'https://celebfleet.com/wp-content/uploads/2022/09/Kaash-plays-boyfriend.webp'
        },
        {
            name: 'Binks',
            location: 'Mumbai',
            url: 'https://www.esportsperson.com/public/uploads/240892930c7e003b509b41a2d1dd8c0c.webp'
        } */

     ]);

     useEffect(() => {
        async function fetchData() {
            const req = await axios.get("/tinder/cards");

            setCars(req.data);
        }

        fetchData();

     }, [])


  return (
    <div className= 'card_container'>
        {
            cars.map( car => (
                <TinderCard 
                    className='swipe'
                    key={car.name}
                    preventSwipe={['up', 'down']}>
                    <div 
                    style={ { backgroundImage: `url(${car.url})` } }
                    className='card'>
                        <h2>{car.name}</h2>
                        <h3>{car.location}</h3>
                    </div>
                </TinderCard>
            ))
        }


    </div>
  )
}

export default TinderCards